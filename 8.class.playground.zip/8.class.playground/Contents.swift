import UIKit


// class

class Vehicle{
    var currentSpeed = 0.0   //<--초기화를 해줘야한다 0.0 stored property
    var description:String {
        return "Traveling at \(currentSpeed) miles per hour"
    }
    func makeNoise() {
        print("noiseless")
    }
}
//클래스는 만들어졌고 인스턴스를 만들어야한다

let someVehicle = Vehicle()

someVehicle.currentSpeed = 1.0
print(someVehicle.description)
someVehicle.makeNoise()

class Bicycle: Vehicle {
    var hasBasket = false
}

let someBicycle = Bicycle()
someBicycle.hasBasket = true
someBicycle.currentSpeed = 15.0
print(someBicycle.description)
print(someBicycle.hasBasket)

class Tandem:Bicycle{
    var currentNumberOfPassengers = 0
    override var description: String{
        return "Traveling at \(currentSpeed) miles per hour, number of passenger :\(currentNumberOfPassengers)"
        
    }
}

let someTandem = Tandem()
someTandem.hasBasket = true
someTandem.currentNumberOfPassengers = 2
someTandem.currentSpeed = 22.0
            
//print("Tandem : \(someTandem.description)")

//매서드로 오버라이드 하는 법
class Train:Vehicle{
    override func makeNoise() {
        print("Choo Choo")
    
    }
}
let someTrain = Train()
someTrain.makeNoise()

//  차를 만들어 볼거고 초기화를 해볼건데 init 어떻게 쓰는지
class Car:Vehicle{
    var gear = 1
    override init() {
        print("Car")
    }
    init(newGear:Int){
        gear = newGear
    }
}

let someCar = Car()

let someCar2 = Car(newGear: 5)
print(someCar2.gear)
